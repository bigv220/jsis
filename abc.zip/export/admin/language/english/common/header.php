<?php
// Additional Texts
$_['text_export']                      = 'Export / Import';
?>